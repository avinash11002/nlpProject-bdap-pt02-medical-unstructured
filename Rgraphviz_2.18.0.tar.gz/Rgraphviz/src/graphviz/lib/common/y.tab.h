#define T_end_br 257
#define T_end_img 258
#define T_row 259
#define T_end_row 260
#define T_html 261
#define T_end_html 262
#define T_end_table 263
#define T_end_cell 264
#define T_end_font 265
#define T_string 266
#define T_error 267
#define T_n_italic 268
#define T_n_bold 269
#define T_n_underline 270
#define T_n_sup 271
#define T_n_sub 272
#define T_BR 273
#define T_br 274
#define T_IMG 275
#define T_img 276
#define T_table 277
#define T_cell 278
#define T_font 279
#define T_italic 280
#define T_bold 281
#define T_underline 282
#define T_sup 283
#define T_sub 284
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union  {
  int    i;
  htmltxt_t*  txt;
  htmlcell_t*  cell;
  htmltbl_t*   tbl;
  htmlfont_t*  font;
  htmlimg_t*   img;
} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
extern YYSTYPE yylval;
